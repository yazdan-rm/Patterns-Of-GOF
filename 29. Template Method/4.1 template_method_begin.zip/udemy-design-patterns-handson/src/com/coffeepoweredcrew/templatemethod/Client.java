package com.coffeepoweredcrew.templatemethod;

public class Client {

	public static void main(String[] args) {

	}
}
