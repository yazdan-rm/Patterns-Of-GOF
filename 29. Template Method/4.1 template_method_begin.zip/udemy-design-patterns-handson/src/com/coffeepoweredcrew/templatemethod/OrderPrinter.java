package com.coffeepoweredcrew.templatemethod;

//Abstract base class defines the template method
public class OrderPrinter {

}
