package com.coffeepoweredcrew.command;

//A Concrete implementation of Command.
public class AddMemberCommand {
		

}
