package com.coffeepoweredcrew.command;

public class Client {

	public static void main(String[] args) throws InterruptedException {
		
	}

}
