package com.coffeepoweredcrew.proxy.dynamic;

//Implement invocation handler. Your "proxy" code goes here.
public class ImageInvocationHandler {
	
}
