package com.coffeepoweredcrew.proxy;

import javafx.geometry.Point2D;

public class Client {

	public static void main(String[] args) {
		
	}

}
