package com.coffeepoweredcrew.proxy;

import javafx.geometry.Point2D;
//Proxy class.
public class ImageProxy {

	
	
}
