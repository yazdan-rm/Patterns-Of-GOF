package com.coffeepoweredcrew.visitor;

public interface Visitor {

}
