package com.coffeepoweredcrew.strategy;

import java.util.Collection;

//Concrete strategy
public class SummaryPrinter {

	
}
