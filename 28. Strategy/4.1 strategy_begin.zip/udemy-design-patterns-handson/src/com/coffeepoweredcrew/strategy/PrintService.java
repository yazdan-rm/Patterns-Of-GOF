package com.coffeepoweredcrew.strategy;


import java.util.LinkedList;

//Context 
public class PrintService {

    public PrintService() {
        
    }

    public void printOrders(LinkedList<Order> orders) {
        
    }
}
