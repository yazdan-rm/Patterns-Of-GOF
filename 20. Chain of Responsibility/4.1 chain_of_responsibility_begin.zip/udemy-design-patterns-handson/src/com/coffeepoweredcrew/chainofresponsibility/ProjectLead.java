package com.coffeepoweredcrew.chainofresponsibility;

//A concrete handler
public class ProjectLead {

}
