package com.coffeepoweredcrew.chainofresponsibility;

public class Client {

	public static void main(String[] args) {
	   
	}

	
}
