package com.coffeepoweredcrew.chainofresponsibility;

//Abstract handler
public class Employee {

	
}