package com.coffeepoweredcrew.nullobject;

public class NullStorageService{

}
