package com.coffeepoweredcrew.state;

public class New {

	
}
