package com.coffeepoweredcrew.state;

public class Cancelled {


}
