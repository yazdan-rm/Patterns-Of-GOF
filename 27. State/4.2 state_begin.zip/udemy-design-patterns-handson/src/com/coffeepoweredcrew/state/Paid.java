package com.coffeepoweredcrew.state;

public class Paid {
	
}
