package com.coffeepoweredcrew.iterator;

public class Client {

	public static void main(String[] args) {

	}

}
