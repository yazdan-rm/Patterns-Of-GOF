package com.coffeepoweredcrew.iterator;

//This enum represents the aggregate from iterator pattern
public enum ThemeColor {

	RED,
	ORANGE,
	BLACK,
	WHITE;

}

