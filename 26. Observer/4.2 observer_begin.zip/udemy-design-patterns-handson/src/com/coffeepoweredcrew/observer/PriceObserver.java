package com.coffeepoweredcrew.observer;

//Concrete observer
public class PriceObserver {

}
