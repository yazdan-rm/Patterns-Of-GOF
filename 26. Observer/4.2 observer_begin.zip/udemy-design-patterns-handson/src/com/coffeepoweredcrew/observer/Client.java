package com.coffeepoweredcrew.observer;

public class Client {

    public static void main(String[] args) {

    }
}
