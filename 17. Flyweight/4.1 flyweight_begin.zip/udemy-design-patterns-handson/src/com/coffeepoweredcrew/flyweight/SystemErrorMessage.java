package com.coffeepoweredcrew.flyweight;

//A concrete Flyweight. Instance is shared
public class SystemErrorMessage {


}
