package com.coffeepoweredcrew.interpreter;

//Terminal expression
public class Permission {

}
